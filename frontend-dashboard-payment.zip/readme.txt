=== Frontend Dashboard Payment ===
Contributors: vinoth06, buffercode
Tags: dashboard, frontend dashboard, payment, paypal
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7DHAEMST475BY
Requires at least: 4.6
Tested up to: 4.9.8
Stable tag: 1.1.1
License: GPL V3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Frontend Dashboard payment allows user to pay the subscription or one time payment via PayPal.

== Description ==
> #### Notice
> This is a Add-on plugin of [Frontend Dashboard](https://wordpress.org/plugins/frontend-dashboard/), So please install [Frontend Dashboard](https://buffercode.com/plugin/frontend-dashboard) to use this plugin **

Frontend Dashboard payment allows user to pay the subscription or one time payment via PayPal.

== Installation ==
1. Upload the “frontend-dashboard-payment” directory to the plugins directory.
2. Go to the plugins setting page and activate “Frontend Dashboard Membership”
3. Go to Frontend Dashboard | Frontend Dashboard | Payment
4. Customize it.

== Frequently Asked Questions ==


== Changelog ==

= v1.1.1 =

* Verify whether the Frontend Dashboard is Installed and Active

= v1.1 =
* Input sanitized.

= v1.0 =
* Public release

== Upgrade Notice ==

== Screenshots ==

